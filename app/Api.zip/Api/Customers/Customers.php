<?php

namespace App\Api\Customers;

use Illuminate\Database\Eloquent\Model;


class Customers extends Model
{
    protected $connection = "sqlsrv3";
    protected $table = "users";
}
