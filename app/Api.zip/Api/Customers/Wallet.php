<?php

namespace App\Api\Customers;

use Illuminate\Database\Eloquent\Model;


class Wallet extends Model
{
    protected $connection = "sqlsrv3";
    protected $table = "customer_wallets";
}
