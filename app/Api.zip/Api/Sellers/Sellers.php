<?php

namespace App\Api\Sellers;

use Illuminate\Database\Eloquent\Model;
use App\Support\Search;
use App\Invoice\Invoice;
use App\Quotation\Quotation;
use App\SalesOrder\SalesOrder;
use App\ClientPayment\ClientPayment;
use App\AdvancePayment\AdvancePayment;
use App\ExchangeRate\ExchangeRate;
use App\Currency;
use App\SellerPayment\SellerPayment;

class Sellers extends Model
{

    protected $connection = "sqlsrv3";
    protected $table = 'sellers';
  
}
