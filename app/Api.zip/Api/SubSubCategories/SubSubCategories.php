<?php

namespace App\Api\SubSubCategories;

use Illuminate\Database\Eloquent\Model;


class SubSubCategories extends Model
{
    protected $connection = "sqlsrv3";
    protected $table = "categories";
}