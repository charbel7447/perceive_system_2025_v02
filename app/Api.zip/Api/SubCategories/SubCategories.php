<?php

namespace App\Api\SubCategories;

use Illuminate\Database\Eloquent\Model;


class SubCategories extends Model
{
    protected $connection = "sqlsrv3";
    protected $table = "categories";
}