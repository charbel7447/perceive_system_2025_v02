<?php

namespace App\Api\Categories;

use Illuminate\Database\Eloquent\Model;


class Categories extends Model
{
    protected $connection = "sqlsrv3";
    protected $table = "categories";
}